﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO.Ports;
using Emgu.CV;
using Emgu.CV.CvEnum;
using Emgu.CV.Structure;
using Emgu.CV.Util;


//Joseph Russo URII Project
namespace Final_Project
{
    public partial class Form1 : Form
    {

        //lab 8 code
        SerialPort arduinoSerial = new SerialPort();
        bool enableCoordinateSending = true;
        Thread serialMonitoringThread;


        //video capture
        VideoCapture _capture;
        Thread _captureThread;


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //creating buffer array
            Byte[] tx_buff = new Byte[5];



            //threading
            _capture = new VideoCapture(1);
            _captureThread = new Thread(ProcessImage);
            _captureThread.Start();


            try
            {
                arduinoSerial.PortName = "COM3";
                arduinoSerial.BaudRate = 9600;
                arduinoSerial.Open();
                serialMonitoringThread = new Thread(MonitorSerialData);
                serialMonitoringThread.Start();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Initializing COM port");
                Close();
            }
        }

        private void ProcessImage()
        {
            //This function will be used for image processing
            while(_capture.IsOpened)
            {
                //Define Mat for the image
                Mat capImage = _capture.QueryFrame();
                //define all var
                var bImage = capImage.ToImage<Gray, byte>().ThresholdBinary(new Gray(125), new Gray(255)).Mat;
                var imageFirst = new Mat();
                var imageSecond = new Mat();
                var imageFinal = new Mat();
                //a point now needs to be created
                Point TargetCenter = new Point();
                //Picture Box needs to be resized
                int resizeHeight = (capImage.Size.Height * ViewerImageBox) / capImage.Size.Width;

                //sizing part
                Size resizeAdjust = new Size(ViewerImageBox.Size.Width, resizeAdjust);
                CvInvoke.Resize(capImage, capImage, resizeAdjust);

                //Use mats for conversion images
                //black and white convert
                //create canny
                CvInvoke.CvtColor(imageFirst, imageFirst, typeof(Bgr), typeof(Gray));
                CvInvoke.Canny(imageFirst, imageSecond, 150, 255);
                //now convery canny to color
                CvInvoke.CvtColor(imageSecond, imageFinal, typeof(Gray), typeof(Bgr));


                //Looping function to find contours
                using (VectorOfVectorOfPoint edges = new VectorOfVectorOfPoint())
                {
                    //CvInvoke for finding the edges
                    CvInvoke.FindContours(imageSecond, edges, null, RetrType.List, ChainApproxMethod.ChainApproxSimple);


                    //for loop that sets up edges
                    //part was based off an example from emgu website
                    for (int b = 0,b < edges.Size, b++)
                    {

                        VectorOfPoint contour = edges[b];
                        using (VectorOfPoint findEdges = new VectorOfPoint())
                        {
                            CvInvoke.ApproxPolyDP(edges, findEdges, CvInvoke.ArcLength(edges, true) * 0.05, true);

                            //the following line is used to find shapes that have an area 
                            //larger than 250. This is so smaller shapes are disregarded
                            if (CvInvoke.ContourArea(findEdges, false)>200)
                            {
                                //This is broken up to two shapes triangle and square
                                //below is square
                                if (findEdges.Size ==4)
                                {
                                    //Below is the commands for drawing bounding boxes
                                    CvInvoke.Polylines(capImage, edges, true, new Bgr(Color.Green).MCvScalar,2);

                                    //Must display on screen in label

                                    Invoke(new Action(() =>
                                    {
                                        labelShape.Text = $"SQUARE IS DETECTED";
                                    }));

                                    //END NESTED IF LOOP
                                }

                                //Instructions for triangle shape
                                else if (findEdges.Size == 3)
                                {
                                    //Below is the commands for drawing bounding boxes
                                    CvInvoke.Polylines(capImage, edges, true, new Bgr(Color.Blue).MCvScalar, 2);

                                    //Must display on screen in label

                                    Invoke(new Action(() =>
                                    {
                                        labelShape.Text = $"TRIANGLE IS DETECTED";
                                    }));
                                }




                                CvInvoke.Polylines(imageFinal, edges, true, new Bgr(Color.Green).MCvScalar);



                                //The following functions will create bounding boxes
                                //The bounding boxes are for the images that have been discovered
                                Rectangle DisplayBoundingBox = CvInvoke.BoundingRectangle(edges[b]);
                                TargetCenter = new Point(DisplayBoundingBox.Y + DisplayBoundingBox.Height / 2, DisplayBoundingBox.X + DisplayBoundingBox.Width / 2,);
                                ObjectDetected(capImage, edges[b], DisplayBoundingBox, CvInvoke.ContourArea(edges));
                            }
                        }
               
                    }



                    //This will display additional info for coordinates and contours
                    Invoke(new Action(() =>
                    {
                        //print to label
                        ContourLabel.Text = $"There have been {edges.Size} detected contours";
                        //display coordinates
                        LabelCoordinate.Text = $"Coordinates X:{TargetCenter.X} Coordinate Y:{TargetCenter.Y}";
                    }

                    //output camera images
                    ViewerImageBox.Image = capImage.Bitmap;

                    BoundingBoxPictureBox.Image = imageFinal.Bitmap;


                    //call angle calculations
                    double hypot = calculate_hypotenuse(TargetPoint.X, TargetPoint.Y);
                    double theta = calculate_angle_theta(TargetPoint.X, TargetPoint.Y);
                    double arm1 = calculate_angle_arm1();
                    double arm2 = calculate_angle_arm2();
                }

            }
        }
        private void MonitorSerialData()
        {


            while (true)
            {
                // block until \n character is received, extract command data
                string msg = arduinoSerial.ReadLine();
                // confirm the string has both < and > characters
                if (msg.IndexOf("<") == -1 || msg.IndexOf(">") == -1)
                {
                    continue;
                }
                // remove everything before the < character
                msg = msg.Substring(msg.IndexOf("<") + 1);
                // remove everything after the > character
                msg = msg.Remove(msg.IndexOf(">"));
                // if the resulting string is empty, disregard and move on
                if (msg.Length == 0)
                {
                    continue;
                }
                // parse the command
                if (msg.Substring(0, 1) == "S")
                {
                    // command is to suspend, toggle states accordingly:
                    //ToggleFieldAvailability(msg.Substring(1, 1) == "1");
                }
                else if (msg.Substring(0, 1) == "P")
                {
                    // command is to display the point data, output to the text field:
                    Invoke(new Action(() =>
                    {
                        // returnPointLabel.Text = $"Returned Point Data: {msg.Substring(1)}";
                    }));
                }

                //send to arduino

            }
        }
        private void sendToSerialMonitor(VectorOfPoint contour, Rectangle boundingBox)
        {
            //define variables center point
            double x = boundingBox.Width / 2 + boundingBox.X;
            double y = boundingBox.Height / 2 + boundingBox.Y;

            byte[] tx_buff = new byte[5];
            //{
            //                    Encoding.ASCII.GetBytes("<")[0],
            //                    Convert.ToByte(x),
            //                    Convert.ToByte()
            //                    Convert.ToByte(y),
            //                    Encoding.ASCII.GetBytes(">")[0]
            //};
            tx_buff[0] = 0x31;
            tx_buff[1] = 0x35;
            tx_buff[2] = 0x41;
            tx_buff[3] = 0x0D;
            tx_buff[4] = 0x0A;
            arduinoSerial.Write(tx_buff, 0, 5);
        }

        private double calculate_hypotenuse(double x, double y)
        {
            return (Math.Sqrt(Math.Pow(x, 2) + Math.Pow(y, 2)));
        }

        //this function will calculate angle theta for the turret
        private double calculate_angle_theta(double alpha, double beta, double theta)
        {
            //variable definition
            double alphaSQUARED, betaSQUARED, thetaSQUARED;

            //calculation portion
            alphaSQUARED = Math.Pow(alpha, 2);
            betaSQUARED = Math.Pow(beta, 2);
            thetaSQUARED = Math.Pow(theta, 2);
            alpha = alphaSQUARED + betaSQUARED - thetaSQUARED;

            //return value
            return (Math.Acos(alpha / beta));
        }

        private double calculate_angle_arm1(double distance)
        {
            //variables
            double hypot, angle1, angle2;

            //calculations for for arm length
            //hypot = calculate_hypotenuse(distance, NC_LENGTH_ARM3); //length of arm 3
            //angle1 = calculate_angle_theta(NC_Length_ARM1, hypot, NC_LENGTH_ARM2); //length of arm 2
            //angle2 = calculate_angle_theta(distance, hypot, NC_LENGTH_ARM3); //length of arm 3

            hypot = calculate_hypotenuse(distance, 5); //length of arm 3
            angle1 = calculate_angle_theta(14, hypot, 7); //length of arm 2
            angle2 = calculate_angle_theta(distance, hypot, 5); //length of arm 3



            //return value
            return (angle1 + angle2);
        }

        private double calculate_angle_arm2(double distance)
        {
            //variables
            double hypot, angle1;

            //calculations for for arm length
            //hypot = calculate_hypotenuse(distance, NC_LENGTH_ARM3);
            //angle1 = calculate_angle_theta(NC_LENGTH_ARM1, NC_LENGTH_ARM2, hypot);

            hypot = calculate_hypotenuse(distance, 5);
            angle1 = calculate_angle_theta(14, 7, hypot);

            //return value
            return (angle1);
        }


        //Test for sending variablesb
        private void Arm1_Click(object sender, EventArgs e)
        {


        }

        private void Arm2_Click(object sender, EventArgs e)
        {

        }

        private void Magnet_Click(object sender, EventArgs e)
        {

        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            _captureThread.Abort();

        }
    }

}
